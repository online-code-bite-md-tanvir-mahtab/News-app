package com.example.news.sunc;

import android.app.IntentService;
import android.content.Intent;

import androidx.annotation.Nullable;

public class NewsIntentService extends IntentService {

    public NewsIntentService() {
        super("NewsIntentService");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        NewsSyncTask.syncNews(NewsIntentService.this);
    }
}
