package com.example.news.network;

import android.content.Context;
import android.net.Uri;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.Scanner;

public class InternetConnection {
    // : 12/2/2020 now for the list of the data we ar going to do some other thing
    // : 12/2/2020 for that we are going to create new mathod and some key.
    // : 12/2/2020 the url we are going to use is this http://api.mediastack.com/v1/news?access_key=f4bf0f3cb6b377283a3cafd85a3b7b6b
    ///now i am going to crete  a LOG tag massage..//
    private static final String LOG_TAG = InternetConnection.class.getSimpleName();

    /*
    now i  am going to have the url of the json
     */
    private static final String WEB_BASE_URL =
            "https://api.nytimes.com/svc/search/v2/articlesearch.json";
    private static final String WEB_SECOND_BASE_URL =
            "https://gnews.io/api/v4/search?";


    /*
    now i am goign to have the key of the uri..
     */
    private static final String PARAM_KEY_QUERY = "q";
    private static final String PARAM_KEY_SORT_BY = "sortBy";
    private static final String PARAM_API_WEB_URI_KEY = "token";
    final static String PARAM_FROM_DAY = "from";
    final static String PARAM_SORT = "sort";
    final static String sortBy = "stars";
    final static String secondKey = "b905a87b486f1518d9f9d82fe2e8154c";

    /*
    nwo i need the key value..
     */
    //private static final String sortBy = "publishedAt";
    private static final String apiKey ="1aldIJOPRYBkPm91bW3rVE3sqTwb8HNl";
    final static String from = "2020-10-27";

    /*
now I am going to have another key for othe list of data that we are going to use
it as a live data
and the uri and the key will provided in the bellow..
http://api.mediastack.com/v1/news?access_key=f4bf0f3cb6b377283a3cafd85a3b7b6b

https://gnews.io/api/v4/top-headlines?token=b905a87b486f1518d9f9d82fe2e8154c

 */
    //now i am going to store the url inside the main_base_url..//
    private static final String MAIN_BASE_URI =
            "https://gnews.io/api/v4/top-headlines?";
    ///for the key title..//
    private static final String KEY_TITLE = "token";
    ///for the key title value....///
    private static final String KEY_TITLE_VLUE = "b905a87b486f1518d9f9d82fe2e8154c";

    /*
    now i am going to create a mathod that will
    parse the live url data with the help
    of the uri parse mahtod..
     */
    public static final URL buildLiveURI (Context context){
        final Uri buidlLiveUri = Uri.parse(MAIN_BASE_URI).buildUpon()
                .appendQueryParameter(KEY_TITLE,KEY_TITLE_VLUE)
                .build();
        ///nwo i am going  to store the null to the url variabgle..//
        URL newUrl = null;
        try{
            newUrl = new URL(buidlLiveUri.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        ///and going to return the url..//
        return newUrl;
    }
    /**
     * nwo i am going to crate the URL mathod that will
     * help me to parse the url with the help of the uri
     */
    public static URL buildURL (String urlSearchkey){
        ///nwo i am goign to access the url and parse it ..//
        Uri buildUri = Uri.parse(WEB_SECOND_BASE_URL).buildUpon()
                .appendQueryParameter(PARAM_KEY_QUERY,urlSearchkey)
                .appendQueryParameter(PARAM_API_WEB_URI_KEY,secondKey)
                .build();
        ///now i am going to declare the uri with null value../
        URL newUrl = null;
        try{
            newUrl = new URL(buildUri.toString());
        }catch (MalformedURLException e) {
            e.printStackTrace();
            Log.e(LOG_TAG,"cant build the uri:"+newUrl);
        }
        Log.e(LOG_TAG,"the URL"+newUrl);
        return  newUrl;
    }


    public static String URLHttpRequestResponse(URL url) throws IOException {
        HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
        try {
            InputStream inputStream = urlConnection.getInputStream();
            Scanner scanner = new Scanner(inputStream);
            scanner.useDelimiter("\\A");
            boolean hasNext = scanner.hasNext();
            if (hasNext){
                return scanner.next();
            }else{
                return null;
            }
        }catch (IOException e){
            Log.e(LOG_TAG,"somethng went wrong"+urlConnection);
        }finally {
            ///now i am goign to desconnect the url connection..//
            urlConnection.disconnect();
        }
        return null;
    }
}
