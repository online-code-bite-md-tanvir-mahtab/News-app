package com.example.news;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.AsyncTaskLoader;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.news.database.NewsContract;
import com.example.news.network.InternetConnection;
import com.example.news.network.JsonParsing;

import java.io.IOException;
import java.net.URL;

public class MainActivity extends AppCompatActivity implements NewsAdapter.NewsAdapterOnClickHandler ,
        LoaderManager.LoaderCallbacks<String[]> {
    //now i am going to create te loader id for the loader calbacks..//
    private static final int LOADER_ID_CALLBACKS = 44;
    ///declaring the log tag massage..//
    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    ///declaring the edit text view...///
    private EditText mEdiTextView;
    private RecyclerView mTextViewDisplay;
    private NewsAdapter mAdapter;
    private  int  mPosition = RecyclerView.NO_POSITION;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //now i am goign to initilize the view..//
        mEdiTextView = (EditText) findViewById(R.id.key_search_edit_view);
        mTextViewDisplay = (RecyclerView) findViewById(R.id.recyclerView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        mTextViewDisplay.setLayoutManager(layoutManager);
        mTextViewDisplay.setHasFixedSize(true);
        //nwo i need to access the adapter class../
        mAdapter = new NewsAdapter(this,this);
        mTextViewDisplay.setAdapter(mAdapter);
    }


    @Override
    public void onClick(long newsData) {
        Intent intent = new Intent(MainActivity.this,DetailsNewsActivity.class);
        Uri contentUri = ContentUris.withAppendedId(NewsContract.NEntry.CONTENT_URI,newsData);
        intent.setData(contentUri);
        startActivity(intent);
    }



    /**
     * now i am goign to create the menu
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //now i am goign to inflate the menu..//
        getMenuInflater().inflate(R.menu.searching_preference_view,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.search_bar){
            //makeSearchQuery();
            getSupportLoaderManager().initLoader(LOADER_ID_CALLBACKS,null,this);
            if (getSupportLoaderManager().hasRunningLoaders()){
                //then in here i am going to show an massage
            }
            return true;
        }
        if (id == android.R.id.home){
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }


    @NonNull
    @Override
    public Loader<String[]> onCreateLoader(int id, @Nullable Bundle args) {
        return new AsyncTaskLoader<String[]>(this) {
            //to hendle the array data we are going to have the array string../
            String[] mNewsData = null;

            @Override
            protected void onStartLoading() {
                if (mNewsData != null){
                    deliverResult(mNewsData);
                }else {
                    forceLoad();
                }
            }

            @Nullable
            @Override
            public String[] loadInBackground() {
                //to get the key we are going to use the String variabe to get the key..//
                String keyToSearch = mEdiTextView.getText().toString();
                ///now i am going to pass the search value to the build Url..//
                URL url = InternetConnection.buildURL(keyToSearch);
                Log.d(LOG_TAG,"url :"+url);
                /*
                now i am going to get the http request of the url..
                 */
                try {
                    String httpUrlRequest = InternetConnection.URLHttpRequestResponse(url);
                    ///now to hendle the json response we are going to pass the http reaquest..//
                    String[] jsonParsing = JsonParsing.keyOfJsonParsing(MainActivity.this,httpUrlRequest);
                    //now i am going to return the json..//
                    return jsonParsing;
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
            }
            /*
            now to delever the result we are going to create a
            mathod that will do that
             */
            public void deleverResult(String[] data){
                mNewsData = data;
                super.deliverResult(data);
            }
        };
    }

    @Override
    public void onLoadFinished(@NonNull Loader<String[]> loader, String[] data) {
        mAdapter.setNewsData(data);
    }

    @Override
    public void onLoaderReset(@NonNull Loader<String[]> loader) {
        mAdapter.setNewsData(null);
    }
}