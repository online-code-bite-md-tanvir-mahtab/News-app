package com.example.news.adapter;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.view.NestedScrollingChild;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.BitmapImageViewTarget;
import com.example.news.NewsAdapter;
import com.example.news.R;
import com.example.news.database.NewsContract;

import java.nio.InvalidMarkException;

public class LiveDataAdapter extends RecyclerView.Adapter<LiveDataAdapter.LiveViewHolder>{
    /*//now i am going to store the list of data in the strig array..//
    private String[] mData;*/
    ///now for the acessing the acivity we are ging to use the context...//
    private Context mContext;
    ///now i am going to get thedata from the cursor...//
    private Cursor mCursor;
    //now i am going to create an interface that will help me to do the clikchendling..//
    private final NewsOnclickHandlerLiveData newsOnclickHandlerLiveData;
    public interface NewsOnclickHandlerLiveData {
        void onClick(long newsData);
    }

    public LiveDataAdapter(NewsOnclickHandlerLiveData onclickHandlerLiveData,Context mContext) {
        this.mContext = mContext;
        this.newsOnclickHandlerLiveData = onclickHandlerLiveData;
    }

    @NonNull
    @Override
    public LiveViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.live_list_item, parent, false);
        return new LiveViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LiveViewHolder holder, int position) {
        mCursor.moveToPosition(position);
        int columnTitle = mCursor.getColumnIndex(NewsContract.NEntry.TABLE_TITLE);
        int columnDescription = mCursor.getColumnIndex(NewsContract.NEntry.TABLE_DESCRIPTION);
        int columnImage = mCursor.getColumnIndex(NewsContract.NEntry.TABLE_IMAGE);
        String stringTitle = mCursor.getString(columnTitle);
        String stringDescription = mCursor.getString(columnDescription);
        String stringImage = mCursor.getString(columnImage);
        holder.mTitleView.setText(stringTitle);
        holder.mDesctiption.setText(stringDescription);
        Glide.with(mContext).load(stringImage)
                .thumbnail(0.5f)
                .placeholder(R.drawable.image_loading)
                .into(holder.mImageView);
    }

    @Override
    public int getItemCount() {
        if (mCursor == null){
            return 0;
        }
        return mCursor.getCount();
    }

    /*
        now i am going to create a class that will hendle the work
        to connecting with the layout...
         */
    public class LiveViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        public TextView mTitleView;
        public TextView mDesctiption;
        public ImageView mImageView;

        public LiveViewHolder(@NonNull View itemView) {
            super(itemView);
            ///now i am going to inisilize the view..//
            mTitleView = (TextView) itemView.findViewById(R.id.live_title_view) ;
            mDesctiption = (TextView ) itemView.findViewById(R.id.live_description_view);
            mImageView = (ImageView) itemView.findViewById(R.id.news_images);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            //now i am going to get the adapter position.////
            int position = getAdapterPosition();
            mCursor.moveToPosition(position);
            long id = mCursor.getLong(0);
            newsOnclickHandlerLiveData.onClick(id);
        }
    }
    public void swapTheData(Cursor data){
        mCursor = data;
        notifyDataSetChanged();
    }
}
