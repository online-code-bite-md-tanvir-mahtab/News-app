package com.example.news.network;

import android.content.ContentValues;
import android.content.Context;
import android.media.Image;
import android.util.Log;

import androidx.loader.content.AsyncTaskLoader;

import com.example.news.LiveDataAcitivity;
import com.example.news.MainActivity;
import com.example.news.database.NewsContract;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JsonParsing {
    ///lets first create the log tag massage..//
    private static final String LOG_TAG  = JsonParsing.class.getSimpleName();

    /*
    now i am going to declare the json keyword and initialize them
     */
    private static final String JSON_NEWS_OBJECT_KEYWORD_OF_RESULT = "totalArticles";
    private static final String JSON_NEWS_ARTICLES = "articles";
    private static final String JSON_NEWS_TITLE = "title";
    private static final String JSON_NEWS_DESCRIPTION = "description";
    private static final String JSON_NEWS_CONTENT = "content";
    private static final String JSON_NEWS_IMAGES = "image";

    //now i am going to store the list of the data ..//
    ///and for that i will declare a variable and set it to null..//
    private static String[] newsList = null;
    /*
    now i am going to create a new mathod the type of array string
    and its known as keyOfLiveDataJsonParsing
     */
    public static ContentValues[] keyOfLiveDataJsonParsing(Context context, String httprequestResponse) throws JSONException {
        ///now i am going to parse the json object..//
        JSONObject jsonObject = new JSONObject(httprequestResponse);
        int totalResult = jsonObject.getInt(JSON_NEWS_OBJECT_KEYWORD_OF_RESULT);
        if (totalResult == 0){
            Log.e(LOG_TAG,"the result is none");
        }else {
            Log.e(LOG_TAG,"the url has some data");
        }
        ///now i am goign to get the jsonArray object from the json objectArray..//
        JSONArray jsonArray = jsonObject.getJSONArray(JSON_NEWS_ARTICLES);
        ///nwo i am going to call the string object and initialize it...///
        ContentValues[] contentValues = new ContentValues[jsonArray.length()];
        ///now i am goign to create the for loop for nesting out the array of sthejson..//
        for (int i = 0; i<jsonArray.length();i++){
            ///now i amgoing to parse the array json  object..//
            JSONObject newJsonObject = jsonArray.getJSONObject(i);
            ///now i am going to get the title key..//
            String jsonTitle = newJsonObject.getString(JSON_NEWS_TITLE);
            ///now i am going to get the discription key...//
            String jsonDiscription = newJsonObject.getString(JSON_NEWS_DESCRIPTION);
            ///now i am going to get the content of the news..//
            String jsonContent = newJsonObject.getString(JSON_NEWS_CONTENT);
            String jsonImages = newJsonObject.getString(JSON_NEWS_IMAGES);
            Log.d(LOG_TAG,"the image :"+ jsonImages);

            ContentValues values = new ContentValues();
            ///now i am going to put the data to the vlues...//
            /*values.put(NewsContract.NEntry.TABLE_IMAGE,jsonImages);*/
            values.put(NewsContract.NEntry.TABLE_IMAGE, jsonImages);
            values.put(NewsContract.NEntry.TABLE_TITLE,jsonTitle);
            values.put(NewsContract.NEntry.TABLE_DESCRIPTION,jsonDiscription);
            ///now i am going to put the data in to the array contentValues..//
            contentValues[i] = values;
        }
        ///and here i am going to return the array string..//
        return  contentValues;
    }
    public static String[] keyOfJsonParsing (MainActivity context, String httprequestResponse) throws JSONException {
        ///now i am going to parse the json object..//
        JSONObject jsonObject = new JSONObject(httprequestResponse);
        int totalResult = jsonObject.getInt(JSON_NEWS_OBJECT_KEYWORD_OF_RESULT);
        if (totalResult == 0){
            Log.e(LOG_TAG,"the result is none");
        }else {
            Log.e(LOG_TAG,"the url has some data");
        }
        ///now i am goign to get the jsonArray object from the json objectArray..//
        JSONArray jsonArray = jsonObject.getJSONArray(JSON_NEWS_ARTICLES);
        ///nwo i am going to call the string object and initialize it...///
        newsList = new String[jsonArray.length()];
        ///now i am goign to create the for loop for nesting out the array of sthejson..//
        for (int i = 0; i<jsonArray.length();i++){
            ///now i amgoing to parse the array json  object..//
            JSONObject newJsonObject = jsonArray.getJSONObject(i);
            ///now i am going to get the title key..//
            String jsonTitle = newJsonObject.getString(JSON_NEWS_TITLE);
            ///now i am going to get the discription key...//
            String jsonDiscription = newJsonObject.getString(JSON_NEWS_DESCRIPTION);
            ///now i am going to get the content of the news..//
            String jsonContent = newJsonObject.getString(JSON_NEWS_CONTENT);
            String jsonImages = newJsonObject.getString(JSON_NEWS_IMAGES);
            Log.d(LOG_TAG,"the image :"+ jsonImages);
            ///now i am going to store the data to the array string with the help of index value..//
            newsList[i] =jsonImages + " - " + jsonTitle + " - " + jsonDiscription + " - " + jsonContent;
        }
        ///and here i am going to return the array string..//
        return  newsList;
    }
}
