package com.example.news.setting;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.preference.PreferenceManager;

import com.example.news.R;

public class NewsPrefernece {
    /**
     * now i am going to crete a boolean mathod that will check
     * are the notification enabled..
     */
    public static boolean areNotificationEnableds(Context context){
        ///now i am going to have the notification defalult key..//
        String desplayNotificationKey = context.getString(R.string.pref_enable_notification);
        boolean shuldDisplayNotification =context.getResources()
                .getBoolean(R.bool.show_notification_by_default);
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        // : 12/29/2020 i have many thing to do here
        boolean shuldDisplay = sp.getBoolean(desplayNotificationKey,shuldDisplayNotification);
        return shuldDisplay;
    }
    /**
     * now i am going to create an mathod that will return the
     * last notification when it was displayed..
     * @param context
     */
    public static long getLastNotificationTimeInMillis(Context context){
        String lastNotification = context.getString(R.string.pref_last_notification);
        ////now i am going to get the preference..//
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        long lastNotify = preferences.getLong(lastNotification,0);
        return lastNotify;
    }
    public static long getEllapsedTimeSinceLantNotification(Context context){
        long lastNotification = NewsPrefernece.getLastNotificationTimeInMillis(context);
        long timeSinceLastNotification = System.currentTimeMillis() - lastNotification;
        return  timeSinceLastNotification;
    }
    /**
     * now i am going to crete a mathod that will save the notification time..
     */
    public static void saveLastNotification(Context context , long timeOfNotification){
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sp.edit();
        String lastNotification = context.getString(R.string.pref_last_notification);
        editor.putLong(lastNotification,timeOfNotification);
        editor.apply();
    }
}
