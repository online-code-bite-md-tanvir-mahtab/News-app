package com.example.news;

import android.content.Context;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.loader.app.LoaderManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.BitmapImageViewTarget;
import com.bumptech.glide.request.target.Target;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.NewsViewHolder> {
    private static final String LOG_TAG = NewsAdapter.class.getSimpleName();
    ///now to store the data we are going to declare a array string variable..//
    private String[] mNewsData;
    private final NewsAdapterOnClickHandler mClickHandler;
    private final Context mContext;
    private Cursor mCursor;

    ///now i am going to create the onclickhendaling interface..//
    public interface NewsAdapterOnClickHandler {
        void onClick(long newsData);
    }
    /*f4bf0f3cb6b377283a3cafd85a3b7b6b*/

    public NewsAdapter(NewsAdapterOnClickHandler clickHandler, Context mContext) {
        mClickHandler = clickHandler;
        this.mContext = mContext;
    }



    @NonNull
    @Override
    public NewsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_of_the_news, parent, false);
        return new NewsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NewsViewHolder holder, int position) {
        holder.mTitleView.setText(mNewsData[position]);
        holder.mDesctiptionView.setText(mNewsData[position]);
        // : 11/30/2020 now we need to do some work with the image
        Glide.with(mContext).load(mNewsData[position])
                .thumbnail(0.5f)
                .placeholder(R.drawable.ic_launcher_background)
                .into(holder.mImageView);

    }

    @Override
    public int getItemCount() {
        if (null == mNewsData) return 0;
        return mNewsData.length;
    }

    public void setNewsData(String[] newsData) {
        mNewsData = newsData;
        notifyDataSetChanged();
    }
    public class NewsViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView mTitleView;
        public TextView mDesctiptionView;
        public ImageView mImageView;

        ///nwo i am goign to set the text view fromt he list layout..//
        public NewsViewHolder(@NonNull View itemView) {
            super(itemView);
            mImageView = (ImageView) itemView.findViewById(R.id.news_images);
            mTitleView = (TextView) itemView.findViewById(R.id.title_view) ;
            mDesctiptionView = (TextView) itemView.findViewById(R.id.discription_view);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            mCursor.moveToPosition(position);
            long data = mCursor.getLong(0);
            mClickHandler.onClick(data);
        }
    }
}
