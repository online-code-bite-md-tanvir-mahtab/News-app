package com.example.news;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.AsyncTaskLoader;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.news.adapter.LiveDataAdapter;
import com.example.news.database.FakeNewsData;
import com.example.news.database.NewsContract;
import com.example.news.network.InternetConnection;
import com.example.news.network.JsonParsing;
import com.example.news.network.NotificationUtil;
import com.example.news.setting.SettingActivity;
import com.example.news.sunc.NewsIntentService;
import com.example.news.sunc.NewsSynsImediate;

import java.io.IOException;
import java.net.URL;

public class LiveDataAcitivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> ,LiveDataAdapter.NewsOnclickHandlerLiveData{
    ///for the versioncontrol we need to add the id of th loader..//
    private static final int LOADERS_ID = 44;
    ///declaring the log tag massage..//
    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    //nwo ia m going to declare the recycler view and adapterview...//
    private RecyclerView mRecyclerView;
    private LiveDataAdapter mAdapter;
    //now i am going to have the projection that i went to desplay in the list of the news data..//
    private static final String[] PROJECTION = {

            NewsContract.NEntry.TABLE_TITLE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_data_acitivity);
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView2);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        mRecyclerView.setLayoutManager(layoutManager);
        //now i am gong to create the instance of the adapter calsss..//
        mAdapter = new LiveDataAdapter(this,this);
        mRecyclerView.setAdapter(mAdapter);
        getSupportLoaderManager().initLoader(LOADERS_ID,null,this);
        ///FakeNewsData.insertIntoData(this);
        NewsSynsImediate.inisialized(this);

    }


    /**
     * now i am goign to create the menu
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //now i am goign to inflate the menu..//
        getMenuInflater().inflate(R.menu.refresh_the_view,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.referesh_me){
            try {
                Thread.sleep(2000);
                //makeSearchQuery();
                getSupportLoaderManager().restartLoader(LOADERS_ID,null,this);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            return true;
        }
        if (id == R.id.setting){
            Intent settingIntent = new Intent(LiveDataAcitivity.this , SettingActivity.class);
            startActivity(settingIntent);
        }
        if (id == R.id.search_place){
            Intent searchIntent = new Intent(LiveDataAcitivity.this,MainActivity.class);
            startActivity(searchIntent);
        }
        return super.onOptionsItemSelected(item);
    }

    @NonNull
    @Override
    public Loader<Cursor> onCreateLoader(int id, @Nullable Bundle args) {
        //creating the projection that i went to desplay...//
        String[] projection = {
                NewsContract.NEntry._ID,
                NewsContract.NEntry.TABLE_TITLE,
                NewsContract.NEntry.TABLE_DESCRIPTION,
                NewsContract.NEntry.TABLE_IMAGE
        };
        return new CursorLoader(
                this,
                NewsContract.NEntry.CONTENT_URI,
                projection,
                null,null,null
        );
    }

    @Override
    public void onLoadFinished(@NonNull Loader<Cursor> loader, Cursor data) {
        mAdapter.swapTheData(data);

    }

    @Override
    public void onLoaderReset(@NonNull Loader<Cursor> loader) {
        mAdapter.swapTheData(null);
    }

    @Override
    public void onClick(long id) {
        /*Toast.makeText(this,"the data:" + newsData,Toast.LENGTH_SHORT).show();*/
        ///now i am gong to inisialize the intnet data..//
        Intent data = new Intent(LiveDataAcitivity.this,DetailsNewsActivity.class);
        Uri contentUri = ContentUris.withAppendedId(NewsContract.NEntry.CONTENT_URI,id);
        data.setData(contentUri);
        startActivity(data);
    }
}