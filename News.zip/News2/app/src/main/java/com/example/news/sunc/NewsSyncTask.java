package com.example.news.sunc;

import android.app.Notification;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.text.format.DateUtils;
import android.util.TimeUtils;
import android.widget.Toast;

import com.example.news.database.NewsContract;
import com.example.news.network.InternetConnection;
import com.example.news.network.JsonParsing;
import com.example.news.network.NotificationUtil;
import com.example.news.setting.NewsPrefernece;

import org.json.JSONException;

import java.io.IOException;
import java.net.URL;

public class NewsSyncTask {
    synchronized public static void syncNews(Context context){
        try{
            //now i am going to get the url ..///
            URL newURl = InternetConnection.buildLiveURI(context);
            String urlRequest = InternetConnection.URLHttpRequestResponse(newURl);
            ContentValues[] contentValues= JsonParsing.keyOfLiveDataJsonParsing(context,urlRequest);
            if (contentValues != null && contentValues.length != 0){
                ContentResolver contentResolver = context.getContentResolver();
                contentResolver.delete(
                        NewsContract.NEntry.CONTENT_URI,
                        null,
                        null
                );
                contentResolver.bulkInsert(
                        NewsContract.NEntry.CONTENT_URI,
                        contentValues
                );
            }
            ///now i have created a  boolean type that will check the notification is enabled..///
            boolean isNotificationEnabled = NewsPrefernece.areNotificationEnableds(context);
            if (isNotificationEnabled){
                Toast.makeText(context,"By enabling the notification you will get update and other thing",Toast.LENGTH_SHORT);
            }
            //now now i am going to findout the last notification when it was heppend..//
            long timeSinceLastNotification = NewsPrefernece.getEllapsedTimeSinceLantNotification(context);
            ///now i am going to crete a boolean variable for the current day..//
            boolean oneDayPassSinceLastNotification = false;
            boolean oneHourPassedSinceLastNotification = false;
            if (timeSinceLastNotification >= DateUtils.HOUR_IN_MILLIS){
                oneHourPassedSinceLastNotification  = true;
            }
            if (timeSinceLastNotification >= DateUtils.DAY_IN_MILLIS){
                oneDayPassSinceLastNotification = true;
            }
            if (isNotificationEnabled && oneHourPassedSinceLastNotification){
                NotificationUtil.notificationNewsForUser(context);
            }
            if (isNotificationEnabled && oneDayPassSinceLastNotification){
                NotificationUtil.notificationNewsForUser(context);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
