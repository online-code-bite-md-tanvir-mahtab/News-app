package com.example.news.sunc;

import com.firebase.jobdispatcher.*;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Build;

import androidx.annotation.RequiresApi;

public class NewsJobDespatcher extends JobService {
    private AsyncTask<Void,Void,Void> mFetchNewsTask;
    @Override
    public boolean onStartJob(final JobParameters params) {
        mFetchNewsTask = new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                //now i am going to get the cntext...//
                Context context = getApplicationContext();
                NewsSyncTask.syncNews(context);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                jobFinished(params,false);
            }
        };
        mFetchNewsTask.execute();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        if (mFetchNewsTask != null){
            mFetchNewsTask.cancel(true);
        }
        return true;
    }
}
