package com.example.news.database;

import android.content.ContentValues;
import android.content.Context;
import android.widget.ListAdapter;

import java.util.ArrayList;
import java.util.List;

public class FakeNewsData {
    private static ContentValues createSomeTestWeatherValue(){
        ContentValues values = new ContentValues();
        values.put(NewsContract.NEntry.TABLE_TITLE,"some love to code");
        values.put(NewsContract.NEntry.TABLE_DESCRIPTION,"their are meny programmer who love to code");

        values.put(NewsContract.NEntry.TABLE_TITLE,"some love to code");
        values.put(NewsContract.NEntry.TABLE_DESCRIPTION,"their are meny programmer who love to code");
        values.put(NewsContract.NEntry.TABLE_TITLE,"some love to code");
        values.put(NewsContract.NEntry.TABLE_DESCRIPTION,"their are meny programmer who love to code");
        values.put(NewsContract.NEntry.TABLE_TITLE,"some love to code");
        values.put(NewsContract.NEntry.TABLE_DESCRIPTION,"their are meny programmer who love to code");
        return values;
    }
    public static void insertIntoData(Context context){
        List<ContentValues> fakeValues = new ArrayList<>();
        for (int i = 0 ; i<2;i++){
            fakeValues.add(FakeNewsData.createSomeTestWeatherValue());
        }
        context.getContentResolver().bulkInsert(
                NewsContract.NEntry.CONTENT_URI,
                fakeValues.toArray(new ContentValues[2])
        );
    }
}
