package com.example.news.database;

import android.net.Uri;
import android.provider.BaseColumns;

public class NewsContract {
    // : 11/4/2020 we need to crete the authority and jpathe in heare

    ///lets declar the authority as a string variable..//
    public static final String CONTENT_AUTHORITY = "com.example.news";
    ///now i amp going to declare the uri..//
    public static final Uri  BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);
    //now for the path we are going to declare the variable..//oi
    public static final String CONTENT_PATH = "nt";
    public static final class NEntry implements BaseColumns {
        // : 11/4/2020 tjhen we are goign to add the authority to the uri with the help of pare mathod
        public static final Uri CONTENT_URI  = Uri.withAppendedPath(BASE_CONTENT_URI,CONTENT_PATH);
        ///for the id column we are ghoing to do this..//
        public  static final String COLUMN_ID = BaseColumns._ID;
        ///for the table name we are goping to do this..//
        public static final String TABLE_NAME  = "nt";
        ///for the title we are going to do this
        public static final String TABLE_TITLE = "title";
        //for the description..//
        public static final String TABLE_DESCRIPTION = "description";
        public static final String TABLE_IMAGE = "image";

    }
}
