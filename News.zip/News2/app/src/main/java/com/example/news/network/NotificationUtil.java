package com.example.news.network;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.example.news.MainActivity;
import com.example.news.R;
import com.example.news.database.NewsContract;
import com.example.news.setting.NewsPrefernece;

public class NotificationUtil {
    //now i am going to crete an array to store the column name....///
    private static final String[] projection = {
            NewsContract.NEntry._ID,
            NewsContract.NEntry.TABLE_TITLE
    };
    ///now i am going to declare an instant to identify the value..//
    private static final int NEWS_NOTIFICATION_ID = 3004;
    /**
     * now i am going to crete a mathod that will hendle the notification
     * logic
     * @param context
     */
    public static void notificationNewsForUser(Context context){
        Uri contentUri = NewsContract.NEntry.CONTENT_URI;
        Cursor cursor = context.getContentResolver().query(
                contentUri,
                projection,
                null,
                null,
                null
        );
        ///now i am gong to move the cursor to the positon of the neds..//
        if (cursor.moveToFirst()){
            int newsId = cursor.getColumnIndex(NewsContract.NEntry._ID);
            int newsTitle = cursor.getColumnIndex(NewsContract.NEntry.TABLE_TITLE);
            int id = cursor.getInt(newsId);
            String title = cursor.getString(newsTitle);
            ///now i am going to create the notification with the help of the notificationbuilder..//
            NotificationCompat.Builder notificationBuilder =new NotificationCompat.Builder(context)
                    .setColor(ContextCompat.getColor(context, R.color.colorPrimary))
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setContentTitle("News App")
                    .setContentText(id + title)
                    .setDefaults(Notification.DEFAULT_VIBRATE)
                    .setAutoCancel(true);
            //because i didn't create the detail activity so it will open the app...//
            Intent intent = new Intent(context, MainActivity.class);
            ///to create the propeer pending intent ...//
            TaskStackBuilder taskStackBuilder = TaskStackBuilder.create(context);
            taskStackBuilder.addNextIntentWithParentStack(intent);
            PendingIntent resultPendingIntent = taskStackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);
            notificationBuilder.setContentIntent(resultPendingIntent);
            ///now i am going to have the reference of the notificationmanager..//
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            //now i am going to notify the user with the heop of the notification id..//
            notificationManager.notify(NEWS_NOTIFICATION_ID,notificationBuilder.build());
            // : 12/27/2020 now i need to work with the seting option ..
            // : 12/27/2020 then i will do the other things..
            NewsPrefernece.saveLastNotification(context,System.currentTimeMillis());
        }
        cursor.close();
    }
}
