package com.example.news.fake;

public class FakeNeswsData {
}
