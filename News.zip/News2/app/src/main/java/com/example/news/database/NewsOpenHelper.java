package com.example.news.database;

import android.content.Context;
import android.database.ContentObservable;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class NewsOpenHelper extends SQLiteOpenHelper {
    /* now i am goign to create the database name and database version */
    private static final String DATABASE_TABLE_NAME = "news.db";
    private static final int DATABASE_VERSION = 2;
    public NewsOpenHelper(Context context){
        ///nwo in here i need the data base name  and the database version
        super(context,DATABASE_TABLE_NAME,null ,DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        // : 11/3/2020 i have to create the table in this variable
        final String SQL_TABLE_CREATION = "CREATE TABLE "    + NewsContract.NEntry.TABLE_NAME + " (" +
                NewsContract.NEntry._ID           + " INTEGER PRIMARY KEY, " +
                NewsContract.NEntry.TABLE_TITLE    + " TEXT NOT NULL,       " +
                NewsContract.NEntry.TABLE_DESCRIPTION    + " TEXT NOT NULL,  " +
                NewsContract.NEntry.TABLE_IMAGE    + " BLOB);";

        db.execSQL(SQL_TABLE_CREATION);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // : 11/4/2020 i also need to ad some drop keyword work for this part in the future
        db.execSQL("DROP TABLE IF EXISTS "  + NewsContract.NEntry.TABLE_NAME);
        onCreate(db);
    }
}
