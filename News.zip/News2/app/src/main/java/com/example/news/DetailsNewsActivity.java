package com.example.news;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ShareCompat;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.service.autofill.TextValueSanitizer;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.request.target.BitmapImageViewTarget;
import com.example.news.database.NewsContract;

import org.w3c.dom.Text;
import com.example.news.database.NewsContract.NEntry;

import java.io.ByteArrayInputStream;

public class DetailsNewsActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {
    private static final String LOG_TAG = DetailsNewsActivity.class.getSimpleName();

    ///geting the id of the loader option....//
    private static final int LOADER_ID = 100;
    /*
    now i am going to crete the uri to store the intent uri data
     */
    private Uri mContentUri ;
    TextView mDetailTitleTextView;
    TextView mDetailDescriptionTextView;
    ImageView mDetailImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_news);
        mDetailTitleTextView = (TextView) findViewById(R.id.detail_text_view);
        mDetailDescriptionTextView = (TextView) findViewById(R.id.content_detail_view);
        mDetailImageView = (ImageView) findViewById(R.id.detail_image_view);
        //now i am going to get the data....//
        Intent intent = getIntent();
        mContentUri = intent.getData();
        if (mContentUri == null){
            Log.e(LOG_TAG,"the data is empty");
        }else {
            Log.e(LOG_TAG,"the data :" + mContentUri);
            ///now i am going to inisialize the loader manager..//
            getSupportLoaderManager().initLoader(LOADER_ID,null,this);
        }

    }

    @NonNull
    @Override
    public Loader<Cursor> onCreateLoader(int id, @Nullable Bundle args) {
        ///now i am gong to crete a projection that will help me to desplay...//
        String[] projection = {
                NEntry._ID,
                NEntry.TABLE_TITLE,
                NEntry.TABLE_DESCRIPTION,
                NEntry.TABLE_IMAGE
        };
        return new CursorLoader(this,
                mContentUri,
                projection,
                null,
                null,
                null
        );
    }

    @Override
    public void onLoadFinished(@NonNull Loader<Cursor> loader, Cursor data) {
        if (data.moveToFirst()){
            int indexTitle = data.getColumnIndex(NEntry.TABLE_TITLE);
            int indexContent  = data.getColumnIndex(NEntry.TABLE_DESCRIPTION);
            int indexImage = data.getColumnIndex(NEntry.TABLE_IMAGE);
            String title =  data.getString(indexTitle);
            String content = data.getString(indexContent);
            byte[] image = data.getBlob(indexImage);
            Bitmap bitmap = BitmapFactory.decodeByteArray(image,0,image.length);
            mDetailTitleTextView.setText(title);
            mDetailDescriptionTextView.setText(content);
            mDetailImageView.setImageBitmap(bitmap);
        }
    }

    @Override
    public void onLoaderReset(@NonNull Loader<Cursor> loader) {
        mDetailTitleTextView.setText("");
        mDetailDescriptionTextView.setText("");

    }
    private Intent shareIntentCompact() {

        Intent intent = ShareCompat.IntentBuilder.from(this)
                .setType("text/plain")
                .setText(mContentUri+"Newws")
                .getIntent();
        return intent;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.shareing_news_to_other,menu);
        MenuItem item  = menu.findItem(R.id.shareing);
        item.setIntent(shareIntentCompact());
        return true;
    }


}