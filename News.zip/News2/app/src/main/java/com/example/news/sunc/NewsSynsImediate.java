package com.example.news.sunc;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;

import com.example.news.database.NewsContract;
import com.firebase.jobdispatcher.Constraint;
import com.firebase.jobdispatcher.FirebaseJobDispatcher;
import com.firebase.jobdispatcher.GooglePlayDriver;
import com.firebase.jobdispatcher.Driver;
import com.firebase.jobdispatcher.Job;
import com.firebase.jobdispatcher.JobService;
import com.firebase.jobdispatcher.Lifetime;
import com.firebase.jobdispatcher.Trigger;

import java.util.concurrent.TimeUnit;

public class NewsSynsImediate {
    /*
    now I  am going to create a constant to sync the data every 3 to 4 hour...
     */
    private static final int SYNC_INTERVAL_HOUR = 1;
    private static final int SYNC_INTERVAL_SECONDS   =(int) TimeUnit.MINUTES.toSeconds(SYNC_INTERVAL_HOUR);
    private static final int SYNC_FLEXTIME_SECONDS = SYNC_INTERVAL_SECONDS/1;
    ///now i am going to create a field the type will be boolean..//
    private static boolean sInitialized ;

    //now i am going to add the tag that will identify the sync tag..//
    private static final String NEWS_SYNC_TAG = "news-sync";

    /**
     * now i am going to create a mathod that will schedule hour..
     * @param context
     */
    static void schedulFirebseJobDespatcherSync(Context context){
        ////now i am going to get the googleplay service..//
        Driver driver = new GooglePlayDriver(context);
        FirebaseJobDispatcher jobDispatcher = new FirebaseJobDispatcher(driver);
        Job syncJobService = jobDispatcher.newJobBuilder()
                .setService(NewsJobDespatcher.class)
                .setTag(NEWS_SYNC_TAG)
                .setConstraints(Constraint.ON_ANY_NETWORK)
                .setLifetime(Lifetime.FOREVER)
                .setTrigger(Trigger.executionWindow(SYNC_INTERVAL_SECONDS , SYNC_INTERVAL_SECONDS + SYNC_FLEXTIME_SECONDS))
                .setReplaceCurrent(true)
                .build();
        jobDispatcher.schedule(syncJobService);
    }

    /*
    now i am going to crete a smart sync that iwll help in the future..//
     */
    synchronized public static void inisialized(final Context context){
        if (sInitialized)return;
        sInitialized = true;

        schedulFirebseJobDespatcherSync(context);
        /*
        now i am going to check if the uri contentprovider is empty or not
         */
        new AsyncTask<Void , Void,Void>(){

            @Override
            protected Void doInBackground(Void... voids) {
                ///nwo i am gong to inisialized the uri..//
                Uri newUri = NewsContract.NEntry.CONTENT_URI;
                String[] projection = {
                        NewsContract.NEntry._ID
                };
                Cursor cursor = context.getContentResolver().query(
                        newUri,
                        projection,
                        null,
                        null,
                        null
                );
                if (null == cursor || cursor.getCount() == 0){
                    imediateSync(context);
                }
                cursor.close();
                return null;
            }
        }.execute();
    }



    public static void imediateSync(final  Context context){
        Intent intent = new Intent(context,NewsIntentService.class);
        context.startService(intent);
    }
}
