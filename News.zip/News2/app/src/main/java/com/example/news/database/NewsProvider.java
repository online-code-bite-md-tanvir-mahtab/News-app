package com.example.news.database;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class NewsProvider extends ContentProvider {
    /*
    now i am going to create the code to hendle the
     */
    public static final int CODE_NEWS = 100;
    public static final int CODE_NEWS_SINGLE = 101;
    ///nwo i am  going to put the urmatcher mahtod in to the urimatcher variable...//
    private static final UriMatcher sUriMatcher = buildUriMatcher();
    /**
     * now i am going to create the urimatcher
     */
    private static UriMatcher buildUriMatcher(){
        final  UriMatcher matcher = new UriMatcher(UriMatcher.NO_MATCH);
        // TODO: 11/4/2020  i need to create the addUri to match the uri matcher
        //now i am going to add the multiple rows  line to the urimatcher..//
        matcher.addURI(NewsContract.CONTENT_AUTHORITY,NewsContract.CONTENT_PATH,CODE_NEWS);
        //now for the single rows out of 3 to 1 we are going to do this..//
        matcher.addURI(NewsContract.CONTENT_AUTHORITY,NewsContract.CONTENT_PATH+"/#",CODE_NEWS_SINGLE);
        return matcher;
    }




    private NewsOpenHelper mDbHeoper;

    @Override
    public boolean onCreate() {
        Context context = getContext();
        mDbHeoper = new NewsOpenHelper(context);
        return true;
    }



    @Override
    public int bulkInsert(@NonNull Uri uri, @NonNull ContentValues[] values) {
        final SQLiteDatabase db = mDbHeoper.getWritableDatabase();

        switch (sUriMatcher.match(uri)) {

            case CODE_NEWS:
                db.beginTransaction();
                int rowsInserted = 0;
                try {
                    for (ContentValues value : values) {
                        /*long weatherDate =
                                value.getAsLong(WeatherContract.WeatherEntry.COLUMN_DATE);
                        if (!SunshineDateUtils.isDateNormalized(weatherDate)) {
                            throw new IllegalArgumentException("Date must be normalized to insert");
                        }*/

                        long rowId = db.insert(NewsContract.NEntry.TABLE_NAME, null, value);
                        if (rowId <= 0) {
                            rowsInserted++;
                            throw new SQLException("Unable to insert the data in the table.."+uri);
                        }
                    }
                    db.setTransactionSuccessful();
                } finally {
                    db.endTransaction();
                }

                if (rowsInserted > 0) {
                    getContext().getContentResolver().notifyChange(uri, null);
                }

                return rowsInserted;

            default:
                return super.bulkInsert(uri, values);
        }
    }
    // TODO: 11/4/2020 we also need to ;careate the buldinsert to insert the data and its verry usefull for the server data
    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        // : 11/4/2020 i also need to query the data form the datafbase with the help of the sqlite database
        //nwo i need the database..//
        final SQLiteDatabase database = mDbHeoper.getReadableDatabase();
        //lets create the variable called Cursor..//
        Cursor cursor ;
        switch (sUriMatcher.match(uri)){
            case CODE_NEWS:{
                cursor = database.query(NewsContract.NEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                break;
            }
            case CODE_NEWS_SINGLE:{
                selection = NewsContract.NEntry._ID + "=?";
                selectionArgs = new String[]{String.valueOf(ContentUris.parseId(uri))};
                cursor = database.query(NewsContract.NEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        null);
                break;
            }
            default:
                throw  new UnsupportedOperationException("Unknow uri :"+uri);
        }
        cursor.setNotificationUri(getContext().getContentResolver(),uri);
        return cursor;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        return null;
    }


    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        //nwo i am going to create a tracker that wil keep track which value is deleted...//
        int rowsDeleted;
        if (null == selection) selection = "1";
        switch (sUriMatcher.match(uri)) {

            case CODE_NEWS:
                rowsDeleted = mDbHeoper.getWritableDatabase().delete(
                        NewsContract.NEntry.TABLE_NAME,
                        selection,
                        selectionArgs);

                break;

            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }
        if (rowsDeleted !=0){
            getContext().getContentResolver().notifyChange(uri,null);
        }
        return rowsDeleted;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }

    @Override
    public void shutdown() {
        mDbHeoper.close();
        super.shutdown();
    }
}
